-- module (NICHT ÄNDERN!)
module CrazyhouseBot
    ( getMove
    , listMoves
    ) 
    where

import Data.Char
-- Weitere Modulen können hier importiert werden

import Util

--- external signatures (NICHT ÄNDERN!)
getMove :: String -> String
getMove state = let move = ((splitOn ',' (listMoves state)) !! 0) in substring 1 (length move) move -- YOUR IMPLEMENTATION HERE


listMoves :: String -> String
listMoves state = "[a2-c4,c2-h4,q-c8]"-- YOUR IMPLEMENTATION HERE


-- YOUR IMPLEMENTATION FOLLOWS HERE

substring :: Int -> Int -> String -> String
substring i j s = take (j - i) (drop i s)

getState :: String -> ([String], String, Char)
getState state = let config = splitOn ' ' state in 
                 let board = splitOn '/' (addSpace (config !! 0)) in
                 let reserve = board !! (length board - 1) in
                 let rows = take (length board - 1) board in
                 let player = config !! 1 !! 0 in 
                 (rows, reserve, player)
    
getBoard :: ([String], String, Char) -> [String]
getBoard (rows, reserve, player) = rows

between low high x = low <= x && x <= high
isRank = between '2' '8'

fromNumberToOnes :: Int -> String 
fromNumberToOnes 1 = ['1']
fromNumberToOnes x = ['1'] ++ fromNumberToOnes (x - 1)

addSpace :: String -> String 
addSpace [] = []
addSpace (x : xs) = if isRank x then fromNumberToOnes (digitToInt x) ++ addSpace xs else [x] ++ addSpace xs

type Position = (Int, Int)
type Field = String
type Move = String
type Color = Char
type Piece = (Position, Color)

colorToDir :: Color -> Int
colorToDir color = if color == 'w' then (-1) else 1

fieldToPosition :: Field -> Position
fieldToPosition field = (8 - (ord (field !! 1) - 48), ord (field !! 0) - 97)

positionToField :: Position -> Field 
positionToField (i, j) = [chr (j + 97)] ++ [chr (56 - i)]

getAllPieceMoves :: Char -> Field -> [Move]
getAllPieceMoves 'p' field = getPawnMoves (fieldToPosition field, 'b')
getAllPieceMoves 'P' field = getPawnMoves (fieldToPosition field, 'w')
getAllPieceMoves 'n' field = getKnightMoves (fieldToPosition field, 'b')
getAllPieceMoves 'N' field = getKnightMoves (fieldToPosition field, 'w')
getAllPieceMoves 'k' field = getKingMoves (fieldToPosition field, 'b')
getAllPieceMoves 'K' field = getKingMoves (fieldToPosition field, 'w')
getAllPieceMoves 'r' field = getRookMoves (fieldToPosition field)
getAllPieceMoves 'R' field = getRookMoves (fieldToPosition field)
getAllPieceMoves 'b' field = getBishopMoves (fieldToPosition field)
getAllPieceMoves 'B' field = getBishopMoves (fieldToPosition field)



positionsToMove :: Position -> Position -> Move
positionsToMove (x1, y1) (x2, y2) = positionToField (x1, y1) ++ ['-'] ++ positionToField (x2, y2)

getPawnMoves :: Piece -> [Move]
getPawnMoves ((i, j), color) = let dir = colorToDir color in [
                                    positionsToMove (i, j) (i + dir, j), 
                                    positionsToMove (i, j) (i + (2 * dir), j),
                                    positionsToMove (i, j) (i + dir, j + dir),
                                    positionsToMove (i, j) (i + dir, j - dir)
                                ] 
getKnightMoves :: Piece -> [Move]
getKnightMoves ((i, j), color) = [
                                 positionsToMove (i, j) (i + 2, j + 1),
                                 positionsToMove (i, j) (i + 2, j - 1),
                                 positionsToMove (i, j) (i - 2, j + 1),
                                 positionsToMove (i, j) (i - 2, j - 1),
                                 positionsToMove (i, j) (i + 1, j + 2),
                                 positionsToMove (i, j) (i - 1, j + 2),
                                 positionsToMove (i, j) (i + 1, j - 2),
                                 positionsToMove (i, j) (i - 1, j - 2)
                                ]
getKingMoves :: Piece -> [Move]
getKingMoves ((i, j), color) = [
                                 positionsToMove (i, j) (i + 1, j - 1),
                                 positionsToMove (i, j) (i + 1, j),
                                 positionsToMove (i, j) (i + 1, j + 1),
                                 positionsToMove (i, j) (i, j - 1),
                                 positionsToMove (i, j) (i, j + 1),
                                 positionsToMove (i, j) (i - 1, j - 1),
                                 positionsToMove (i, j) (i - 1, j),
                                 positionsToMove (i, j) (i - 1, j + 1)
                                ]

getRookMoves :: Position -> [Move]
getRookMoves (i, j) = getRookMoves' (i, j) True 7 1 ++ getRookMoves' (i,j) True 7 (-1) ++ getRookMoves' (i,j) False 7 1 ++ getRookMoves' (i,j) False 7 (-1)

getRookMoves' :: Position -> Bool -> Int -> Int -> [Move]
getRookMoves' (i,j) horiz 0 dir = []
getRookMoves' (i,j) horiz steps dir = getRookMoves' (i,j) horiz (steps - 1) dir ++ [if horiz then positionsToMove (i,j) (i, j + steps * dir) else positionsToMove (i,j) (i + steps * dir, j)]


getBishopMoves :: Position -> [Move]
getBishopMoves (i, j) = getBishopMoves' (i, j) 7 1 1 ++ getBishopMoves' (i,j) 7 1 (-1) ++ getBishopMoves' (i,j) 7 (-1) 1 ++ getBishopMoves' (i,j) 7 (-1) (-1)

getBishopMoves' :: Position -> Int -> Int -> Int -> [Move]
getBishopMoves' (i,j) 0 dir_x dir_y = []
getBishopMoves' (i,j) steps dir_x dir_y = getBishopMoves' (i,j) (steps - 1) dir_x dir_y ++ [positionsToMove (i,j) (i + steps * dir_y, j + steps * dir_x)]

getQueenMoves :: Position -> [Move]
getQueenMoves (i,j) = getRookMoves (i,j) ++ getBishopMoves (i,j)