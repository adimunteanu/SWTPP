package de.tuberlin.sese.swtpp.gameserver.test.crazyhouse;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ CrazyhouseGameTest.class, TryMoveIntegrationTest.class})
public class AllTests {
}
